
 $(document).ready(function(){   
    fetch("stad.json")
          .then(function(response) {
            return response.json();           
        })
        .then(function(lander) {
             landlist=lander
            console.log (landlist);
                for(var i=0; i < 3; i++){
                    console.log(landlist[i].countryname);
                    $(".lander").append("<br><a href='#' onclick='printcity("+landlist[i].id+")'>"+landlist[i].countryname+"</a>");
                      }
            })
            printcity = function(id){
                console.log("print city funktion")
                console.log(id)

                // fetch cities
             
                fetch("city.json")
                .then(function(response){
                    return response.json();
                })

                .then(function(stader){
                    $(".stader").empty();
                    for(var i=0; i<stader.length; i++){
                        if(stader[i].countryid == id){
                            console.log(JSON.stringify(stader[i]));                            
                            $(".stader").append("<br><a href='#' >"+stader[i].stadname+"</a>");
                            
                        }
                    }

               })
             } 

               });
        

