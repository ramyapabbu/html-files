
 $(document).ready(function(){  

    var printstring="w";
    printString = printstring+w;
    console.log(printstring);
        


});
addword=function(w){
    console.log(w)
    };
    
    

